from .xkcd_rgb import xkcd_rgb
from .crayons import crayons
